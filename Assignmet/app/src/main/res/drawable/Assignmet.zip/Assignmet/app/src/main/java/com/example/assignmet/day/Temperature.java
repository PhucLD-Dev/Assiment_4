package com.example.assignmet.day;

public class Temperature {
    private Maximum Maximum;
    private Minimum Minimum;

    public com.example.assignmet.day.Maximum getMaximum() {
        return Maximum;
    }

    public void setMaximum(com.example.assignmet.day.Maximum maximum) {
        Maximum = maximum;
    }

    public com.example.assignmet.day.Minimum getMinimum() {
        return Minimum;
    }

    public void setMinimum(com.example.assignmet.day.Minimum minimum) {
        Minimum = minimum;
    }
}
