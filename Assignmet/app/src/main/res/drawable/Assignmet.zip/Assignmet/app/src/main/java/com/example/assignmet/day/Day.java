package com.example.assignmet.day;

public class Day {
    private int Icon;

    public int getIcon() {
        return Icon;
    }

    public void setIcon(int icon) {
        Icon = icon;
    }
}
