package com.example.assignmet.day;

import java.util.List;

public class Wheather1 {
    private List<DailyForecasts> DailyForecasts;

    public List<com.example.assignmet.day.DailyForecasts> getDailyForecasts() {
        return DailyForecasts;
    }

    public void setDailyForecasts(List<com.example.assignmet.day.DailyForecasts> dailyForecasts) {
        DailyForecasts = dailyForecasts;
    }
}
